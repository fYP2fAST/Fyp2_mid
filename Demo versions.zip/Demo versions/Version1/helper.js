



/*
var config = {
    apiKey: "AIzaSyBnbbbQLF847y4Dxw485ncgOKu_pOQzoD0",
    authDomain: "fyp2-143a1.firebaseapp.com",
    databaseURL: "https://fyp2-143a1.firebaseio.com",
    projectId: "fyp2-143a1",
    storageBucket: "fyp2-143a1.appspot.com",
    messagingSenderId: "772659482627"
  };
  firebase.initializeApp(config);
  database=firebase.database();
  */

function myFunction(p1) {

alert(p1);


}

